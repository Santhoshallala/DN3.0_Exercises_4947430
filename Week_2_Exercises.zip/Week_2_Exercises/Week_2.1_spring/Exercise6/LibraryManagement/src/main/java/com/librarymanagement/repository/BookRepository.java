package com.librarymanagement.repository;

import org.springframework.stereotype.Repository;

@Repository
public class BookRepository {
    // repository methods
}
