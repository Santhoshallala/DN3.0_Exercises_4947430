package com.librarymanagement;

import com.librarymanagement.service.BookService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
    public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        BookService bookService = context.getBean(BookService.class);

        // Test the configuration
        System.out.println("BookService initialized: " + (bookService != null));
        System.out.println("BookRepository initialized via constructor: " + (bookService.getBookRepository() != null));

        // Call a method to trigger the AOP logging
        bookService.someServiceMethod();
    }
}
