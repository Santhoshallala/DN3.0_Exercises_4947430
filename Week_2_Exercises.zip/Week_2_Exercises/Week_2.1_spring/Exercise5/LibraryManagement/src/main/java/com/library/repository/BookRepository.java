package com.librarymanagement.repository;

public class BookRepository {
    // repository methods
}
