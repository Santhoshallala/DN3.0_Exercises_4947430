package com.example.EmployeeManagementSystem.repository;

import com.example.EmployeeManagementSystem.entity.Employee;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    // Method to find all employees with pagination and sorting
    Page<Employee> findAll(Pageable pageable);

    // Method to find all employees with sorting
    List<Employee> findAll(Sort sort);
}
