package com.example.EmployeeManagementSystem.projections;


import org.springframework.beans.factory.annotation.Value;

public interface CustomEmployeeProjection {
    Long getId();
    String getName();

    @Value("#{target.name + ' (' + target.department.name + ')'}")
    String getEmployeeWithDepartment();
}
