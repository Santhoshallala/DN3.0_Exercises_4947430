package com.example.EmployeeManagementSystem.controller;

import com.example.EmployeeManagementSystem.entity.Employee;
import com.example.EmployeeManagementSystem.repository.EmployeeCustomRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/employees/custom")
public class EmployeeCustomController {

    @Autowired
    private EmployeeCustomRepository employeeCustomRepository;

    @GetMapping("/by-department/{departmentName}")
    public ResponseEntity<List<Employee>> getEmployeesByDepartmentName(@PathVariable String departmentName) {
        List<Employee> employees = employeeCustomRepository.findByDepartmentNameUsingNamedQuery(departmentName);
        return new ResponseEntity<>(employees, HttpStatus.OK);
    }

    @GetMapping("/by-email-domain/{domain}")
    public ResponseEntity<List<Employee>> getEmployeesByEmailDomain(@PathVariable String domain) {
        List<Employee> employees = employeeCustomRepository.findByEmailDomainUsingNamedQuery(domain);
        return new ResponseEntity<>(employees, HttpStatus.OK);
    }
}
