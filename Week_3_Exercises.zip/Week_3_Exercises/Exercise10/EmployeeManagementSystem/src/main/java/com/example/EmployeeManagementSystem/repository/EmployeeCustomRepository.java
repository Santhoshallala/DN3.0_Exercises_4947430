package com.example.EmployeeManagementSystem.repository;

//package com.example.employeemanagementsystem.repository;

import com.example.EmployeeManagementSystem.entity.Employee;

import java.util.List;

public interface EmployeeCustomRepository {
    List<Employee> findByDepartmentNameUsingNamedQuery(String departmentName);
    List<Employee> findByEmailDomainUsingNamedQuery(String domain);
}
