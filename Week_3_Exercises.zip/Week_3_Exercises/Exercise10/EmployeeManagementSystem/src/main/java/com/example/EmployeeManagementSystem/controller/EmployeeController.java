package com.example.EmployeeManagementSystem.controller;

import com.example.EmployeeManagementSystem.projections.CustomEmployeeProjection;
import com.example.EmployeeManagementSystem.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/employees")
public class EmployeeController {

    @Autowired
    private EmployeeRepository employeeRepository;

    // Get Custom Employee Projections
    @GetMapping("/custom-projections")
    public ResponseEntity<List<CustomEmployeeProjection>> getCustomEmployeeProjections() {
        List<CustomEmployeeProjection> employees = employeeRepository.findCustomEmployeeProjections();
        return new ResponseEntity<>(employees, HttpStatus.OK);
    }
}
