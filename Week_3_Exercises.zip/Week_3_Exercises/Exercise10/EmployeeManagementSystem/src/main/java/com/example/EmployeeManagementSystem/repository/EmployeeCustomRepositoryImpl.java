package com.example.EmployeeManagementSystem.repository;
//package com.example.employeemanagementsystem.repository;

import com.example.EmployeeManagementSystem.entity.Employee;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class EmployeeCustomRepositoryImpl implements EmployeeCustomRepository {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public List<Employee> findByDepartmentNameUsingNamedQuery(String departmentName) {
        return entityManager.createNamedQuery("Employee.findByDepartmentName", Employee.class)
                .setParameter("departmentName", departmentName)
                .getResultList();
    }

    @Override
    public List<Employee> findByEmailDomainUsingNamedQuery(String domain) {
        return entityManager.createNamedQuery("Employee.findByEmailDomain", Employee.class)
                .setParameter("domain", "%" + domain)
                .getResultList();
    }
}
