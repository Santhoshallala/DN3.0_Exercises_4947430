package com.example.BookstoreAPI.service;

import com.example.BookstoreAPI.controller.BookController;
import com.example.BookstoreAPI.dto.BookDTO;
import com.example.BookstoreAPI.entity.Book;
import com.example.BookstoreAPI.exception.ResourceNotFoundException;
import com.example.BookstoreAPI.repository.BookRepository;
import org.springframework.hateoas.Link;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BookService {

    @Autowired
    private BookRepository bookRepository;

    @Autowired
    private BookController bookController;

    public BookDTO findById(Long id) {
        Book book = bookRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Book not found with ID: " + id));

        BookDTO bookDTO = new BookDTO();
        // Set properties from Book to BookDTO

        // Adding self link
        Link selfLink = WebMvcLinkBuilder.linkTo(
                        WebMvcLinkBuilder.methodOn(BookController.class).getBookById(id))
                .withSelfRel();
        bookDTO.add(selfLink);

        // Add more links as needed

        return bookDTO;
    }

    // Other methods
}
