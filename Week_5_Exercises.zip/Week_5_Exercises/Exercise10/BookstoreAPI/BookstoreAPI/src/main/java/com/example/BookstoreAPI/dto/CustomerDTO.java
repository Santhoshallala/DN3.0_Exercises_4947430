package com.example.BookstoreAPI.dto;

import org.springframework.hateoas.RepresentationModel;

public class CustomerDTO extends RepresentationModel<CustomerDTO> {
    private Long id;
    private String name;
    private String email;

    // Getters and Setters
}
