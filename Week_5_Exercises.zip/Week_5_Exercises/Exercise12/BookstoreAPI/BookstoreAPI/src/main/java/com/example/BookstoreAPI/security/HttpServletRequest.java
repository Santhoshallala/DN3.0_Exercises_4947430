package com.example.BookstoreAPI.security;

public class HttpServletRequest {
}
