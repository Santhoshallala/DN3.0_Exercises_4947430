package com.example.BookstoreAPI.dto;
import io.swagger.v3.oas.annotations.media.Schema;

@Schema(description = "Data Transfer Object representing a Book")
public class BookDTO {

    @Schema(description = "Unique identifier of the book", example = "1")
    private Long id;

    @Schema(description = "Title of the book", example = "Effective Java")
    private String title;

    @Schema(description = "Author of the book", example = "Joshua Bloch")
    private String author;

    @Schema(description = "Price of the book", example = "45.99")
    private Double price;

    @Schema(description = "ISBN number of the book", example = "978-0134685991")
    private String isbn;

    // Getters and Setters
}
