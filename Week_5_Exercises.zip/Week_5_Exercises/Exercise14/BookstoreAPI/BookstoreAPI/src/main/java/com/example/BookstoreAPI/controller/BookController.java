package com.example.BookstoreAPI.controller;

import com.example.BookstoreAPI.dto.BookDTO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/books")
@Tag(name = "Books", description = "API for managing books")
public class BookController {

    @GetMapping
    @Operation(summary = "Get all books", description = "Retrieve a list of all books in the store")
    public List<BookDTO> getAllBooks() {
        // Your code here
        return List.of();
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get book by ID", description = "Retrieve a specific book by its ID")
    public BookDTO getBookById(@PathVariable Long id) {
        // Your code here
        return null;
    }

    @PostMapping
    @Operation(summary = "Add a new book", description = "Add a new book to the store")
    public BookDTO addBook(@RequestBody BookDTO bookDTO) {
        // Your code here
        return bookDTO;
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update a book", description = "Update the details of an existing book")
    public BookDTO updateBook(@PathVariable Long id, @RequestBody BookDTO bookDTO) {
        // Your code here
        return bookDTO;
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete a book", description = "Delete a book from the store by its ID")
    public void deleteBook(@PathVariable Long id) {
        // Your code here
    }
}
